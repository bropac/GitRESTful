package com.example.capelli14014.login;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;

public class accessoEseguito extends Activity
{

    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accesso_eseguito);

        back = (Button)findViewById(R.id.b);

        back.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent activity = new Intent(accessoEseguito.this,MainActivity.class);
                startActivity(activity);
                ActivityCompat.finishAffinity(accessoEseguito.this);
            }
        });
    }

}
