package com.example.capelli14014.login;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    private Button login,signup;
    private EditText username,password;

    private String url = "http://192.168.1.102/bropac/apiPHP/login.php";
    JSONParser jsonParser=new JSONParser();
    int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (Button)findViewById(R.id.l);
        signup = (Button)findViewById(R.id.s);
        username = (EditText)findViewById(R.id.usr);
        password = (EditText)findViewById(R.id.pwd);

        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                AttemptLogin attemptLogin= new AttemptLogin();
                url = "http://192.168.1.102/bropac/apiPHP/login.php";
                attemptLogin.execute(username.getText().toString(),password.getText().toString());
            }
        });

        signup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(i==0)
                {
                    i=1;
                    username.setVisibility(View.VISIBLE);
                    login.setVisibility(View.GONE);
                    signup.setText("CREATE ACCOUNT");
                }
                else
                {
                    signup.setText("REGISTER");
                    username.setVisibility(View.GONE);
                    login.setVisibility(View.VISIBLE);
                    i=0;

                    AttemptLogin attemptLogin= new AttemptLogin();
                    url = "http://192.168.1.102/bropac/apiPHP/signup.php";
                    attemptLogin.execute(username.getText().toString(),password.getText().toString(),"");

                }
            }
        });



    }

    private class AttemptLogin extends AsyncTask<String, String, JSONObject>
    {
        @Override protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override protected JSONObject doInBackground(String... args)
        {
            String password = args[1];
            String name= args[0];

            ArrayList params = new ArrayList();
            params.add(new BasicNameValuePair("username", name));
            params.add(new BasicNameValuePair("password", password));

            JSONObject json = jsonParser.makeHttpRequest(url, "POST", params);

            return json;
        }

        protected void onPostExecute(JSONObject result)
        {
            try
            {
                if (result != null)
                {
                    Toast.makeText(getApplicationContext(),result.getString("message"),Toast.LENGTH_LONG).show();
                    if(result.getBoolean("status"))
                    {
                        Intent activity = new Intent(MainActivity.this,accessoEseguito.class);
                        startActivity(activity);
                        ActivityCompat.finishAffinity(MainActivity.this);
                    }
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Unable to retrieve any data from server", Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e)
            {
                e.printStackTrace();
            }


        }

    }

}




